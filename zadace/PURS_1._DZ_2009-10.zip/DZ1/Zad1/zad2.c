#include <at91sam7x128.h>


int main(void){
  	
  *AT91C_PIOB_PER=AT91C_PIO_PB28;
  *AT91C_PIOB_PER|=AT91C_PIO_PB0;

  *AT91C_PIOB_OER=AT91C_PIO_PB0;

  while(1){
    if((*AT91C_PIOB_PDSR) & AT91C_PIO_PB28)
		*AT91C_PIOB_SODR=AT91C_PIO_PB0;
	else
		*AT91C_PIOB_CODR=AT91C_PIO_PB0;
  }



}
