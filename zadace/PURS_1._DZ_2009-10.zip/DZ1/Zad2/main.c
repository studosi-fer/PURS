#include <AT91SAM7X128.h>

void pit_handler (void) __irq;
void spurious_handler (void) __irq;

unsigned int brojac=0;

int main(void){
 *(AT91C_AIC_SMR+AT91C_ID_SYS)=(0<<0)|(0<<0);
 *(AT91C_AIC_SVR+AT91C_ID_SYS)= (unsigned int) pit_handler;
 *AT91C_AIC_SPU= (unsigned int) spurious_handler;
 *AT91C_AIC_IECR=1<<AT91C_ID_SYS;

 *AT91C_PITC_PIMR=(3<<24)|(3999<<0);

 *AT91C_PIOB_PER=0xFFFF;
 *AT91C_PIOB_OER=0xFFFF;
 *AT91C_PMC_PCER=(1<<3);

 
 *AT91C_PIOB_SODR=(0xFFFF & brojac);
 
 while(1);

}


void pit_handler (void) __irq {

brojac++;
if(brojac==(0xFFFF+1)) brojac=0;
*AT91C_PIOB_CODR=0xFFFF;
*AT91C_PIOB_SODR=(0xFFFF & brojac);


*AT91C_AIC_EOICR = *AT91C_PITC_PIVR; 
}



void spurious_handler (void) __irq {


*AT91C_AIC_EOICR = *AT91C_PITC_PIVR; 
}


