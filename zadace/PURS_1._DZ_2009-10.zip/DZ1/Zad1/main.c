#include <at91sam7x128.h>


int main(void){
  	
  *AT91C_PIOB_PER=AT91C_PIO_PB28;
  *AT91C_PIOB_PER=0xFF;
  *AT91C_PIOB_PPUDR=0xFF;
  *AT91C_PMC_PCER=(1<<3);

  while(1){
    if((*AT91C_PIOB_PDSR) & AT91C_PIO_PB28){
		*AT91C_PIOB_OER=0xFF;
		*AT91C_PIOB_SODR=0xAA;
	}
	else
		*AT91C_PIOB_ODR=0xFF;
  }



}




