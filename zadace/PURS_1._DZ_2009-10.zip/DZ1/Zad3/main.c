#include <AT91SAM7X128.h>

void startup(void){
*AT91C_PMC_PLLR=(9<<16)|(0x3F<<8)|(1<<0);

while(((*AT91C_PMC_SR)&4));

return;
}

int main(void){
startup();

while(1);

}


